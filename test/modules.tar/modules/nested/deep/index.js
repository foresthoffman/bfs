module.exports = {
	deepModule: ["a"],
	nestedModule: require("../index.js"),
};
